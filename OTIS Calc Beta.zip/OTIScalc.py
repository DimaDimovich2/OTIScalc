import webview
import os
import sys

# Путь к HTML файлу
html_path = os.path.join(os.path.dirname(__file__), 'calculator.html')

# Создаем окно с HTML файлом
webview.create_window('OTIScalc', html_path, width=400, height=600, resizable=False)
webview.start()